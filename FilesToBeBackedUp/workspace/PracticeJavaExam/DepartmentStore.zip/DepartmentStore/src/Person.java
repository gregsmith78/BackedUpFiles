import java.util.*;
public class Person {
	String firstName;
	String lastName;
	String department;
	int accessLevel;
	double hourlyWage;
	double salary;
	double totalHoursWorkedForWeek;
	boolean isSupervisor;
	
	
	public Person(){
		
	}
	public void PrintLines(){
		System.out.println("=====================================");
	}
	
	
	
	

}
